﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBookingSystem
{
    class DataSet
    {
        // static Story[] storylist;
        public static List<Admin> AdminList = new List<Admin>();
        public static List<User> CustomerList = new List<User>();
        // public static List<Comment> CommentList = new List<Comment>();

        // static List<String> names;
    }
}
