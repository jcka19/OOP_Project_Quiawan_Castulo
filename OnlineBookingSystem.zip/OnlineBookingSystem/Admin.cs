﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBookingSystem
{
    class Admin
    {
        public String FirstName, LastName, MiddleName,Id;

        public Admin(String id, String lastname, String firstname, String middlename)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.MiddleName = middlename;
            this.Id = id;
        }
        public String toString()
        {
            return "Employee{" +
                  ", Id='" + Id + '\'' +
                    ", LastName='" + LastName + '\'' +
                    ", FirstName='" + FirstName + '\'' +
                    ", MiddleName='" + MiddleName + '\'' +
                    '}';
        }
        public Admin(String id, String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
        }

    }
}

