﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OnlineBookingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Program p = new Program();
            p.InitData();
            p.ProgramStart();
            Console.Read();
        }
        public void ProgramStart()
        {
            var guid = Guid.NewGuid().ToString();
            Program p = new Program();

        home:

            switch (p.Home())
            {
                case "a":
                case "A":
                    p.Login();
                    break;
                case "b":
                case "B":
                    p.Register();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("========================================================================");
                    Console.WriteLine("\t\t\t\tInvalid Choice");
                    Console.WriteLine("========================================================================");

                    goto home;

            };

        }
        public string Home()
        {
            string option;
            Console.WriteLine("\n************************************************************************");
            Console.WriteLine("\t\t\t\tWELCOME TO");
            Console.WriteLine("\t\tAQJC ONLINE BOOKING SYSTEM");
            Console.WriteLine("************************************************************************");
            Console.WriteLine("================================= OPTION ===============================");
            Console.WriteLine("*************************    A. Login          *************************");
            Console.WriteLine("*************************    B. Register       *************************");
            Console.WriteLine("========================================================================");
            Console.Write("\t\t\tSelect Option:   ");
            option = Console.ReadLine();
            Console.Clear();

            return option;
        }
        public void Login()
        {
        login:
            Program p = new Program();
            string username, password;
            Console.WriteLine("============================================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx LOGIN xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please Input the following **************");
            Console.WriteLine("============================================================================");
            Console.Write("\n\tUsername: ");
            username = Console.ReadLine();
            System.Console.Write("\n\tPassword: ");
            password = null;

            while (true)
            {
                var key = System.Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                    break;
                password += key.KeyChar;
                System.Console.Write("*");

            }
            Console.Clear();

            try
            {
                User respond = DataSet.CustomerList.Find(r => (r.Username == username) && (r.Password == password));

                switch ((respond.Id))
                {
                    case "a":
                    case "A":
                        Login();
                        break;
                };
            }
            catch
            {

                Console.Clear();
                Console.WriteLine("============================================================================");
                Console.WriteLine("\t\t\t\tThe Account Does'nt exist!");
                Console.WriteLine("============================================================================");
                goto login;
            }
            p.LoginHome();

        }
        public void Register()
        {
            Program p = new Program();
            String firstname, lastname, middlename, username, password, birthday;
            Console.WriteLine("===============================================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxx Registration Form xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please input the following **************");
            Console.WriteLine("===============================================================================");
            Console.Write("\tFirst Name:  ");
            firstname = Console.ReadLine();
            Console.Write("\tLast Name:   ");
            lastname = Console.ReadLine();
            Console.Write("\tMiddle Name: ");
            middlename = Console.ReadLine();
            Console.Write("\tBirthday:    ");
            birthday = Console.ReadLine();
            Console.Write("\tUsername:    ");
            username = Console.ReadLine();
            Console.Write("\tPassword:    ");
            password = Console.ReadLine();
            Console.Clear();

            User u = new User(Guid.NewGuid().ToString(), firstname, lastname, middlename, birthday, username, password);
            DataSet.CustomerList.Add(u);
            p.Successful();

        }
        public void Successful()
        {
            Program p = new Program();
            Console.WriteLine("=====================================");
            Console.WriteLine("=====================================");
            Console.WriteLine("||       Congratulation            ||");
            Console.WriteLine("||     your already register       ||");
            Console.WriteLine("||   To AQJC busline services!!    ||");
            Console.WriteLine("=====================================");
            Console.WriteLine("=====================================");
            Console.ReadLine();
            Console.Clear();

            ProgramStart();
        }
        public void EmployeeInfo()
        {
            Program p = new Program();
            String firstname, lastname, middlename, address, status, gender, cellnum, bday, department;
            byte age;

            Console.WriteLine("==============================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Employee Data xxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please input the following **************");
            Console.WriteLine("==============================================================");
            Console.Write("\tFirst Name:         ");
            firstname = Console.ReadLine();
            Console.Write("\tLast Name:          ");
            lastname = Console.ReadLine();
            Console.Write("\tMiddle Name:        ");
            middlename = Console.ReadLine();
            Console.Write("\tAddress:            ");
            address = Console.ReadLine();
            Console.Write("\tBirthday:           ");
            bday = Console.ReadLine();
            Console.Write("\tAge:                ");
            age = byte.Parse(Console.ReadLine());
            Console.Write("\tCivil Status:       ");
            status = Console.ReadLine();
            Console.Write("\tGender:             ");
            gender = Console.ReadLine();
            Console.Write("\tCell Number:        ");
            cellnum = Console.ReadLine();
            Console.Write("\tDepartment:      ");
            department = Console.ReadLine();
            Console.Clear();
            Admin e = new Admin(Guid.NewGuid().ToString(), firstname, lastname, middlename);
            DataSet.AdminList.Add(e);
            p.LoginHome();

        }
        public String LoginHome()
        {
            string id;
            id = Console.ReadLine();
            Program p = new Program();
            User respond;
            String option = "";
            try
            {
                respond = DataSet.CustomerList.Find(r => (r.Id == id));

                Console.WriteLine("***********************************************************************************");
                Console.WriteLine("\t\t\t\tWELCOME TO");
                Console.WriteLine("\t\tAQJC ONLINE BOOKING BUSLINE SERVICES");
                Console.WriteLine("***********************************************************************************");
                Console.WriteLine("===================================================================================");
                Console.WriteLine("====================================== OPTION =====================================");
                Console.WriteLine("********************    A. Reservation                         ********************");
                Console.WriteLine("********************    B. Account Setting                     ********************");
                Console.WriteLine("********************    C. Cancellation                        ********************");
                Console.WriteLine("********************    D. View User List                      ********************");
                Console.WriteLine("********************    E. Add New Employee                    ********************");
                Console.WriteLine("********************    F. View Employee                       ********************");
                Console.WriteLine("********************    G. EXIT                                ********************");
                Console.WriteLine("===================================================================================");
                Console.WriteLine("===================================================================================");
                Console.Write("\t\t\tSelect an Option:   ");
                option = Console.ReadLine();
                Console.Clear();
                switch (option)
                {
                    case "a":
                    case "A":
                        p.Reservation();
                        break;
                    case "b":
                    case "B":
                        AccountSetting();
                        break;
                    case "c":
                    case "C":
                        Cancellation();
                        break;
                    case "d":
                    case "D":
                        DisplayUserList();
                        break;
                    case "e":
                    case "E":
                        EmployeeInfo();
                        break;
                    case "f":
                    case "F":
                        EmployeeUpdate();
                        break;
                    case "g":
                    case "G":
                        Greatings();
                        break;
                    default:
                        Console.WriteLine("\t\t\t\tInvalid Input");
                        break;

                }

                Console.ReadLine();

            }
            catch
            {
                Console.Clear();
            }

            return option;
        }
        public void Reservation()
        {
            Program p = new Program();

            int num, startingpoint;
            string destination;
            double price;

            Console.WriteLine("*********************************************************************************************************************************************************");
            Console.WriteLine("*********************************************************************************************************************************************************");
            Console.WriteLine("*******                                                SAINT BERNARD TO TACLOBAN via SILAGO ROUTE                                                 *******");
            Console.WriteLine("******=============================================================================================================================================== ***");
            Console.WriteLine("******    1.SAINT BERNARD                                ||  2.SAN JUAN                                ||   3.ANAHAWAN                               ***");
            Console.WriteLine("******                   2.San Juan      ----      P10.00||             Anahawan      ----      P10.00 ||             Hinundayan    ----      P10.00 ***");
            Console.WriteLine("******                   3.Anahawan      ----      P20.00||             Hinundayan    ----      P20.00 ||             Hinunangan    ----      P20.00 ***");
            Console.WriteLine("******                   4.Hinundayan    ----      P30.00||             Hinunangan    ----      P30.00 ||             Silago        ----      P30.00 ***");
            Console.WriteLine("******                   5.Hinunangan    ----      P40.00||             Silago        ----      P40.00 ||             Abuyog        ----      P40.00 ***");
            Console.WriteLine("******                   6.Silago        ----      P60.00||             Abuyog        ----      P60.00 ||             Tacloban      ----     P100.00 ***");
            Console.WriteLine("******                   7.Abuyog        ----      P80.00||             Tacloban      ----     P110.00 ||             Saint Bernard ----      P20.00 ***");
            Console.WriteLine("******                   8.Tacloban      ----     P130.00||             Saint Bernard ----      P10.00 ||             San Juan      ----      P10.00 ***");
            Console.WriteLine("******                                                   ||                                            ||                                            ***");
            Console.WriteLine("*********************************************************************************************************************************************************");
            Console.WriteLine("*********************************************************************************************************************************************************");
            Console.WriteLine("******                                                                                                                                                ***");
            Console.WriteLine("******================================================================================================================================================***");
            Console.WriteLine("******    4.HINUNDAYAN                                  ||  5.HINUNANGAN                             ||   6.SILAGO                                    ***");
            Console.WriteLine("******                    San Juan      ----      P20.00||            Anahawan      ----      P10.00 ||             Hinundayan    ----      P10.00    ***");
            Console.WriteLine("******                    Anahawan      ----      P10.00||            Hinundayan    ----      P10.00 ||             Hinunangan    ----      P20.00    ***");
            Console.WriteLine("******                    Hinunangan    ----      P10.00||            Silago        ----      P20.00 ||             Abuyog        ----      P30.00    ***");
            Console.WriteLine("******                    Silago        ----      P20.00||            Abuyog        ----      P40.00 ||             Tacloban      ----      P40.00    ***");
            Console.WriteLine("******                    Abuyog        ----      P40.00||            TAcloban      ----      P80.00 ||             San Juan      ----      P90.00    ***");
            Console.WriteLine("******                    Tacloban      ----      P90.00||            Saint Bernard ----     P100.00 ||             Saint Bernard ----      P60.00    ***");
            Console.WriteLine("******                    Saint Bernard ----      P30.00||            San Juan      ----      P30.00 ||             Anahawan      ----      P30.00    ***");
            Console.WriteLine("******                                                  ||                                           ||                                               ***");
            Console.WriteLine("*********************************************************************************************************************************************************");
            Console.WriteLine("*********************************************************************************************************************************************************");
            Console.WriteLine("Please Select Starting Point:");
            startingpoint = int.Parse(Console.ReadLine());
            Console.WriteLine("Destination: ");
            destination = Console.ReadLine();
            if (startingpoint == 1)
            {
                if (destination == "2")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 1)
            {
                if (destination == "3")
                {
                    price = 20.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 1)
            {
                if (destination == "4")
                {
                    price = 30.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 1)
            {
                if (destination == "5")
                {
                    price = 40.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             P" + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 1)
            {
                if (destination == "6")
                {
                    price = 60.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 1)
            {
                if (destination == "7")
                {
                    price = 80.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 1)
            {
                if (destination == "8")
                {
                    price = 130.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "3")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "4")
                {
                    price = 20.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "5")
                {
                    price = 30.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "6")
                {
                    price = 40.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             P" + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "7")
                {
                    price = 80.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "8")
                {
                    price = 110.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 2)
            {
                if (destination == "1")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "2")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "1")
                {
                    price = 20.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "4")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "5")
                {
                    price = 20.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             P" + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "6")
                {
                    price = 30.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "7")
                {
                    price = 40.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 3)
            {
                if (destination == "8")
                {
                    price = 100.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "2")
                {
                    price = 30.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "3")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "4")
                {
                    price = 10.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "5")
                {
                    price = 20.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             P" + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "6")
                {
                    price = 30.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "7")
                {
                    price = 40.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            if (startingpoint == 4)
            {
                if (destination == "8")
                {
                    price = 90.00;
                    Console.WriteLine("Price:" + price);
                    Console.Write("Enter number of people: ");
                    num = int.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("     AQJC BUSLINE SERVICES                  ");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("**    Seat Number:            (optional)  **");
                    Console.WriteLine("**    Departure Time:           6:00am    **");
                    Console.WriteLine("**                                        **");
                    Console.WriteLine("**   TOTAL:             " + num * price, "**");
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("--------------------------------------------");
                    Console.Read();
                    Console.Clear();
                }
            }
            p.Greatings();
        }
        public void Greatings()
        {
            Console.WriteLine("===============================================");
            Console.WriteLine("===============================================");
            Console.WriteLine("***                                         ***");
            Console.WriteLine("***              THANK YOU                  ***");
            Console.WriteLine("***    for using AQJC Busline Services      ***");
            Console.WriteLine("***                                         ***");
            Console.WriteLine("***                                         ***");
            Console.WriteLine("===============================================");
            Console.WriteLine("===============================================");
           
            Console.Write("Press Any Key to exit");
        }
        public void Cancellation()
        {
            Program p = new Program();

            switch (Confirmation())
            {
                case "1":
                    p.Cancel();
                    break;
                case "2":
                    p.LoginHome();
                    break;
            }
        }
        public void AccountSetting()
        {
            Program p = new Program();
            p.DisplayUserList();
        }
        public string Confirmation()
        {
            string y;
            Console.WriteLine("**********************************");
            Console.WriteLine("Confirm Yes if you want to cancel!");
            Console.WriteLine("*         1. YES                 *");
            Console.WriteLine("*         2. NO                  *");
            Console.WriteLine("**********************************");
            Console.WriteLine("**********************************");


            y = Console.ReadLine();

            return y;
        }
        public void Cancel()
        {
            Console.WriteLine("Your Transaction has been cancel!");
            Console.WriteLine("             THANK YOU           ");
        }
        public void InitData()
        {
            string id1 = Guid.NewGuid().ToString();
            DataSet.CustomerList.Add(new User(Guid.NewGuid().ToString(), "Jessica", "Quiawan", "C", "April", "jcka", "forever19"));
            DataSet.CustomerList.Add(new User(Guid.NewGuid().ToString(), "Antonio", "Quiawan", "C", "April", "anton", "forever19"));

        }
        public void DisplayUserList()
        {
            Program p = new Program();
            {
                Console.WriteLine("==============================================================");
                Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Users List xxxxxxxxxxxxxxxxxxxxxxx");
                Console.WriteLine("==============================================================");
                int count = 1;
                foreach (User s in DataSet.CustomerList)
                {
                    try
                    {

                        Console.WriteLine(count++ + " " + s.toString());
                    }
                    catch
                    {

                    }
                }
                Console.WriteLine("Press any key to Continue");
            }
            p.LoginHome();
        }
        public void EmployeeUpdate()
        {
            Program p = new Program();
            {
                Console.WriteLine("==============================================================");
                Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Employee List xxxxxxxxxxxxxxxxxxxxxxx");
                Console.WriteLine("==============================================================");
                int count = 1;
                foreach (Admin s in DataSet.AdminList)
                {
                    try
                    {

                        Console.WriteLine(count++ + " " + s.toString());
                    }
                    catch
                    {

                    }
                }
            }
            switch (p.List())
            {
                case "1":
                    p.LoginHome();
                    break;
                case "2":
                    p.Greatings();
                    break;
            }
            p.List();
        }
        public string List()
        {
            string input;
            Console.WriteLine("Do You Want To Continue?");
            Console.WriteLine("        1. YES          ");
            Console.WriteLine("        2. NO           ");
            input = Console.ReadLine();

            return input;
        }
    }
}